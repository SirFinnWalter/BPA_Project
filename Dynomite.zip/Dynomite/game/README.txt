COGNITIVE THOUGHT MEDIA
Dynomite!

Instructions:
See "information.pdf" to learn about the game
To start the game, run "play.bat"